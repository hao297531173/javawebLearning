package com.imooc.seller.repositoriesbackup;

import com.imooc.seller.repositories.OrderRepository;

/**
 * 读库repositories
 */
public interface BackupOrderRepository extends OrderRepository{
}
