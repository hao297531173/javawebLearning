package com.imooc;

/**
 * Created by 廖师兄
 * 2017-06-02 17:55
 */
public class LoggerTest2 {
}
