package com.mmall.beans;

import lombok.Getter;

@Getter
public enum CacheKeyConstants {

    SYSTEM_ACLS,

    USER_ACLS;

}
